package io.socket.parser;

public class DecodingException extends RuntimeException {
    public DecodingException(String message) {
        super(message);
    }
}
